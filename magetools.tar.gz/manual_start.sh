#!/bin/bash
echo "Staring ..."
/usr/bin/supervisord -c /etc/supervisord.conf &> /var/log/supervisord.log & 
